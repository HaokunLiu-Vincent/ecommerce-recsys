# Validation evaluation

Mode: full. Selected pipeline: lambdamart.

All retained eligible queries contribute. Smoke is diagnostic only. Conditional ranking and oracle-assisted diagnostics are separate views. This benchmark conditions on future purchases; no online uplift is claimed.
