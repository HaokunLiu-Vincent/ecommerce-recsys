# Final Test evaluation

Mode: full. Frozen selected pipeline: lambdamart.

All candidate budgets and model weights were fixed by Validation. Other pipeline scores are predeclared comparisons, not a new selection. No Test injection or refitting occurred. Smoke metrics are diagnostics.
